/// <reference types="cypress" />

describe('Forms & Data Handling', () => {

  beforeEach(() => {
    cy.visit('/commands/actions')
  })

  it('Fill email input using fixture data', () => {
  cy.fixture('userData').then((data) => {
    cy.get('#email1').type(data.email).should('have.value', data.email)
    })
  })

  it('Handle checkbox selection', () => {
  cy.get('.action-checkboxes input[type="checkbox"]').first().check().should('be.checked')
  cy.get('.action-checkboxes input[type="checkbox"]').first().uncheck().should('not.be.checked')
  })

  it('Handle radio button selection', () => {

  // Select radio1
  cy.get('input[value="radio1"]').check().should('be.checked')

  // Select radio2
  cy.get('input[value="radio2"]').check().should('be.checked')

  // radio1 should now be unchecked automatically
  cy.get('input[value="radio1"]').should('not.be.checked')

})

  it('Handle dropdown selection by value', () => {

  cy.get('.action-select').select('fr-oranges').should('have.value', 'fr-oranges')
  cy.get('.action-select').select('apples').should('have.value','fr-apples')

})

it('Validate button click', () => {
  cy.contains('Submit').click()

})

it('Write and Read file validation', () => {

  // Write data into file
  cy.writeFile('cypress/fixtures/sample.txt', 'Hello Cypress')

  // Read the file and validate content
  cy.readFile('cypress/fixtures/sample.txt').should('equal', 'Hello Cypress')

})

})