/// <reference types="cypress" />

describe('file upload and validate',()=>{
    it('Handle file upload', () => {

    cy.visit('https://the-internet.herokuapp.com/upload')

    cy.get('#file-upload').attachFile('userData.json')
    cy.get('#file-submit').click()
    cy.contains('File Uploaded!').should('be.visible')

    })
})