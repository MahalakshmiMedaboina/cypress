/// <reference types="cypress" />

describe('Cypress E2E Testing demo', () => {
  beforeEach(() => {
    cy.visit('https://example.com')
  })
  afterEach(()=> {
    cy.log('After each test completed')
  })

  it('Assert element', () =>{
    cy.get('h1').should('contain', 'Example Domain')
    cy.get('p').should('be.visible')
    cy.wait(2000)
    cy.title().should('not.contain', 'Google')

  })

  it('Reload and log', () => {
    cy.log('Page loaded successfully')
    cy.reload()
    cy.log('Page reloaded successfully')
  })



})