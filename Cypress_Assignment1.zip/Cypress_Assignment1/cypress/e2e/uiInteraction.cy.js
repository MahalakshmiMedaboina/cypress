/// <reference types="cypress" />

describe('UI Interaction - Modals, Hover, Scroll', () => {

  it.skip('Handle JavaScript Alert', () => {

    cy.visit('https://the-internet.herokuapp.com/javascript_alerts')

    cy.contains('Click for JS Alert').click()

    cy.on('window:alert', (text) => {
      expect(text).to.equal('I am a JS Alert')
    })

  })

  it('Open and assert Modal', () => {
    cy.visit('https://practice-automation.com/modals/')

    // find and click the button to open modal
    cy.get('#simpleModal').click()
    cy.contains('Simple Modal').should('be.visible')
    cy.get('p').contains('Hi, I’m a simple modal.').should('be.visible')

    // close the modal
    cy.get('button[aria-label="Close"]').filter(':visible').first().click()

    
  })

  it('Lets test hover workaround', () => {

    // visit the page
    cy.visit('https://practice-automation.com/hover/')

    //perform hover action
    cy.get("#mouse_over").trigger('mouseover')

    // assert the hover text
    cy.get("#mouse_over").should('contain', 'You did it!')

  })

  it('Device enumalation', () => {

    // visit the page
    cy.viewport('macbook-15')
    cy.viewport(800, 600)
    cy.visit('https://practice-automation.com/hover/')

  })

  it('full page screenshot', () => {
    cy.visit('https://example.com')
    cy.screenshot({overwrite: true})
  })

  it('lets see reloads and logs',()=>{
    cy.visit('https://example.com')
    cy.log('before reload')
    cy.reload()
    cy.log('After reload')

  })

  it('Fill email using custom command', () => {

  cy.visit('/commands/actions')
  cy.enterEmail('qa_custom@example.com')
  cy.get('#email1').should('have.value', 'qa_custom@example.com')

})

})


