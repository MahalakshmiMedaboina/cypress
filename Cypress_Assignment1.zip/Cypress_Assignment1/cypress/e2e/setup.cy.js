/// <reference types='cypress' />

describe("Project setup", () => {
  it("Verify Base URL is working", () => {
    cy.visit("/");
    cy.url().should("include", "cypress.io");
  })

  it("Verify title", () => {
    cy.visit("/");
    cy.title().should("contain", "Kitchen Sink");
  })
});
