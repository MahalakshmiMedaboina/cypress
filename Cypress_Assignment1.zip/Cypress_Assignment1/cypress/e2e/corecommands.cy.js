/// <reference types='cypress' />

describe('Core Commands & DOM Validation', () => {

  beforeEach(() => {
    cy.visit('/commands/actions')
  })

    it('Verify Email Input is Visible', () => {
    cy.get('#email1').should('be.visible')
  })

  it('Check number of primary buttons', () => {
    cy.get('.btn-primary').then((buttons) => {
      cy.log('Number of primary buttons:', buttons.length)
    })
  })

  it('Validate number of primary buttons', () => {
    cy.get('.btn-primary').should('have.length', 2)
  })

  it('Validating multiple properties of email input', ()=>{
    cy.get('#email1').should('be.visible').should('have.attr','placeholder','Email').should('not.be.disabled')
  })

  it('Get placeholder value using invoke()',()=>{
    cy.get('#email1').invoke('attr','placeholder').should('equal','Email')
  })

  it('Validate clear command in email input',()=>{
    cy.get('#email1').type('qa_test@example.com').should('have.value','qa_test@example.com')
    cy.get('#email1').clear().should('have.value','')
  })

  it('Validating Submit button using contains()', ()=>{
    cy.contains('Submit').should('be.visible')
  })

})